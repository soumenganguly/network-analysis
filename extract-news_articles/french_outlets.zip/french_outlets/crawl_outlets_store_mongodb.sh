#!/bin/bash

while true:
      do

	  python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_1_10.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_11_20.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_21_30.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_31_40.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_41_50.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_51_60.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_61_70.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_71_80.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_81_90.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_91_100.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_101_110.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_111_120.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_121_130.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_131_140.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_141_150.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_151_160.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_161_170.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_171_180.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_181_190.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_191_200.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_201_210.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_211_220.txt &&
	      python /home/sougangu/french_outlets/crawl_outlets_store_mongodb.py outlets_221_227.txt
done

