#!/bin/bash

while true
      do

	  python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_0_10.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_10_20.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_20_30.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_30_40.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_40_50.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_50_60.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_60_70.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_70_80.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_80_90.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_90_100.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_100_110.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_110_120.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_120_130.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_130_140.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_140_150.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_150_160.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_160_170.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_170_180.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_180_190.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_190_200.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_200_210.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_210_220.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_220_230.txt &&
	      
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_230_240.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_240_250.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_250_260.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_260_270.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_270_280.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_280_290.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_290_300.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_310_320.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_320_330.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_330_340.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_340_350.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_350_360.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_360_370.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_370_380.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_380_390.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_390_400.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_400_410.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_410_420.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_420_430.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_430_440.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_440_450.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_450_460.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_460_470.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_470_480.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_480_490.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_490_500.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_510_520.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_520_530.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_530_540.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_540_550.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_550_560.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_560_570.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_570_580.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_580_590.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_590_600.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_600_610.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_610_620.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_620_630.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_630_640.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_640_650.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_650_660.txt &&
	      python /home/sougangu/italian_outlets/crawl_outlets_store_mongodb.py outlets_660_667.txt
done

